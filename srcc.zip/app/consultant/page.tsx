import { HeroGeometric } from "@/components/ui/shape-landing-hero";

export default function Page() {
  return (
    <HeroGeometric
      badge="SRCC CONSULTANCY"
      title1="Professional Solutions"
      title2="For Your Business"
    />
  );
}
