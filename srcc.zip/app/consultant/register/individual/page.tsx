import ConsultantRegistrationForm from "@/components/consultant/consultant-registration-form";
import React from "react";

const page = () => {
    return (
        <ConsultantRegistrationForm />
    );
};

export default page;
