import CompanyRegistrationForm from "@/components/consultant/company-registration-form";

export default function CompanyRegistrationPage() {
  return <CompanyRegistrationForm />;
}
